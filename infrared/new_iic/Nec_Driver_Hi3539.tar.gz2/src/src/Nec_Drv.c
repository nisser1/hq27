﻿#include <linux/delay.h>
#include <linux/device.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/gfp.h>
#include <linux/gpio.h>
#include <linux/i2c.h>
#include <linux/init.h>
#include <linux/input.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/irq.h>
#include <linux/kernel.h>
#include <linux/kfifo.h>
#include <linux/kmod.h>
#include <linux/major.h>
#include <linux/miscdevice.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/poll.h>
#include <linux/proc_fs.h>
#include <linux/rtc.h>
#include <linux/seq_file.h>
#include <linux/slab.h>
#include <linux/stat.h>
#include <linux/timer.h>
#include <linux/timex.h>
#include <linux/tty.h>
#include <linux/version.h>
#include <linux/wait.h>
#include <linux/ktime.h>
#include "./Nec.c"

/* fakechen Debug Information && operation */
#define DEBUG
#ifdef DEBUG
#define print(format, args...)                      \
    do {                                            \
        printk("[%s:%d] ", __FUNCTION__, __LINE__); \
        printk(format, ##args);                     \
    } while (0)
#else
#define print(format, args...)
#endif
#define Min(a, b) (a < b ? a : b)

#define Fake_Timer_Jiffes jiffies + HZ/4

#define Fake_Int_DEV_NUM 1                /* 设备号个数 */
#define Fake_Int_MEM_SIZE 2 * 1024 * 1024 /* 2M */
/* 定义IOCTl控制命令 */
#define Fake_MAGIC 'g'
#define Fake_IOC_RNEC _IOR(Fake_MAGIC, 0, int)

/* 创建操作的IOBUF */
static void *Io_Buf = NULL;


struct FakeIntGpioDev {
    dev_t devid;                          /* 设备号 */
    struct cdev cdev;                     /* cdev */
    struct class *class;                  /* 类  /sys/class下的类 */
    struct device *device;                /* 设备 /dev 下的设备 */
    int major;                            /* 主设备号 */
    int minor;                            /* 次设备号 */
    void __iomem *iobase;                 /* io基base */
    struct ztGpioPrivate FakeChenGI;      /* Gpio Int操作模块 */
    int interrupt_gpio1;                  /* 中断引脚1 */
    int interrupt_pin1;                   /* 中断号1 */
    struct i2c_adapter *Int_Gpio_Adapter; /* 适配器 */
    struct mutex lock;                    /* 互斥锁 */
    struct timer_list fake_timer;		  /* 设备要使用的定时器 */
    struct fasync_struct *Nec_queue;	  /* 异步通知 */
 
};

/* ① 确定主设备号，也可以让内核自动分配 */
/* 创建Hello设备结构体 */
struct FakeIntGpioDev FakeIntGpio;


/* ② 定义自己的 file_operations 结构体 */
/* ③ 实现对应的 drv_open/drv_read/drv_write 等函数，填入 file_operations 结构体
 */
static int FakeIntGpioOpen(struct inode *inode, struct file *file);
static int FakeIntGpioRelease(struct inode *inode, struct file *file);
static ssize_t FakeIntGpioWrite(struct file *file, const char __user *buf,
                                size_t size, loff_t *off);
static ssize_t FakeIntGpioRead(struct file *file, char __user *buf, size_t size,
                               loff_t *off);
static int FakeIntGpioFasync(int fd, struct file*filp, int mode);
static int ztIntGpio_I2C_read(struct i2c_adapter *adapter,unsigned char *pBuf);

// ②定义自己的file_operation结构体
static const struct file_operations Fake_Int_ops = {
    .owner = THIS_MODULE,
    .open = FakeIntGpioOpen,
    .release = FakeIntGpioRelease,
    .write = FakeIntGpioWrite,
    .read = FakeIntGpioRead,
    .fasync = FakeIntGpioFasync,
};


static irqreturn_t FakeChenIntIsr(int irq, void *dev_id)
{
	
    mod_timer(&FakeIntGpio.fake_timer,Fake_Timer_Jiffes); 
    return IRQ_HANDLED;


}


/* 定时器处理函数 */
static void fake_do_timer(unsigned long arg)
{
	if(FakeIntGpio.Nec_queue) {
	 	kill_fasync(&FakeIntGpio.Nec_queue, SIGIO, POLL_IN);
	}
}

static int __init FakeIntGpioInit(void)
{
    int ret = 0;
    memset(&FakeIntGpio, 0, sizeof(struct FakeIntGpioDev));
	
    FakeIntGpio.major = 0;  // 主设备号写0让内核自动分配

        /* 1.获取设备号 */
        /* 主设备号不确定，写为0->申请让系统自动分配 */
        if (!FakeIntGpio.major) {
            FakeIntGpio.devid = MKDEV(FakeIntGpio.major, 0);
            // Fake_Int_DEV_NUM 1
            ret = alloc_chrdev_region(
                &FakeIntGpio.devid, 0, Fake_Int_DEV_NUM,
                "FakeIntGpio_driver"); /* (major,0) 对应 FakeIntGpio_driver,
                                        (major,
                                        1~255)都不对应FakeIntGpio_driver */
                                       /* 获取主设备号 */
            FakeIntGpio.major = MAJOR(FakeIntGpio.devid);
            /* 获取次设备号 */
            FakeIntGpio.minor = MINOR(FakeIntGpio.devid);
            print(
                "FakeIntGpio.devid = %d FakeIntGpio.major = %d  "
                "FakeIntGpio.minor = "
                "%d.	\r\n",
                FakeIntGpio.devid, FakeIntGpio.major, FakeIntGpio.minor);
        }
  
        /* 2.初始化cdev,添加驱动 */
        FakeIntGpio.cdev.owner = THIS_MODULE;
        cdev_init(
            &FakeIntGpio.cdev,
            &Fake_Int_ops); /* ls /proc/devices  ----->244 FakeIntGpio_driver */

        /* 3.添加cdev 注册设备以及驱动 */
        ret = cdev_add(&FakeIntGpio.cdev, FakeIntGpio.devid, Fake_Int_DEV_NUM);
    

    /* 4.创建类 */
    FakeIntGpio.class = class_create(
        THIS_MODULE, "FakeIntGpio_class"); /* /sys/class/FakeIntGpio_class */

    /* 5.创建设备 */
    FakeIntGpio.device =
        device_create(FakeIntGpio.class, NULL, FakeIntGpio.devid, NULL,
                      "FakeIntGpio_dev"); /* /dev/FakeIntGpio_dev */

    /* 6.初始化Int_Gpio     GPIO12_2输入模式 */
    ztInitGpioMap(&FakeIntGpio.FakeChenGI);

    /* 7.注册一个Gpio_Int 中断 */
    FakeIntGpio.interrupt_gpio1 = 98;  // GPIO12_2 -> 98
    FakeIntGpio.interrupt_pin1 = gpio_to_irq(FakeIntGpio.interrupt_gpio1);
    print(" irq:%d-%d\n", FakeIntGpio.interrupt_gpio1,FakeIntGpio.interrupt_pin1);
    ret = request_irq(FakeIntGpio.interrupt_pin1, FakeChenIntIsr,
                IRQF_TRIGGER_FALLING, "Fake_Gpio_Int", NULL);

    /* 8.初始化互斥锁 */
    mutex_init(&FakeIntGpio.lock);

	

    /* 9.初始化定时器 */
    init_timer(&FakeIntGpio.fake_timer);
    FakeIntGpio.fake_timer.function = fake_do_timer;
    FakeIntGpio.fake_timer.expires = Fake_Timer_Jiffes; 
    add_timer(&FakeIntGpio.fake_timer); //添加注册定时器

    /* 10.初始化I2c 驱动 */
    FakeIntGpio.Int_Gpio_Adapter = i2c_get_adapter(11);
    if (!FakeIntGpio.Int_Gpio_Adapter)
        printk(KERN_INFO "Faile to Get Adapter\r\n");

    return 0;
}

/* ⑥ 有入口函数就应该有出口函数：卸载驱动程序时，出口函数调用释放函数 */
static void __exit FakeIntGpioExit(void)
{
    print("Io_Buf = %p\r\n", Io_Buf);
    /* 释放申请的内存 */
    if (Io_Buf != NULL) {
        kfree(Io_Buf);
        Io_Buf = NULL;
    }

    if (FakeIntGpio.devid) {
		/* 释放占用的设备号 */
		unregister_chrdev_region(FakeIntGpio.devid, Fake_Int_DEV_NUM);
		/* 删除 cdev */
		cdev_del(&(FakeIntGpio.cdev));

		/* 删除 device */
		device_destroy(FakeIntGpio.class, FakeIntGpio.devid);
		/* 删除 class */
		class_destroy(FakeIntGpio.class);

		/* 释放Gpio资源 */
		ztReleaseGpioMap(&FakeIntGpio.FakeChenGI);
		free_irq(FakeIntGpio.interrupt_pin1, NULL);

		/* 删除定时器 */
		del_timer(&FakeIntGpio.fake_timer);
		
		 /* 释放i2c适配器 */
		i2c_put_adapter(FakeIntGpio.Int_Gpio_Adapter);

    }
}


MODULE_LICENSE("GPL");
module_init(FakeIntGpioInit);
module_exit(FakeIntGpioExit);


static int FakeIntGpioOpen(struct inode *inode, struct file *file)
{
    file->private_data = &FakeIntGpio;
    return 0;
}

static int FakeIntGpioRelease(struct inode *inode, struct file *file)
{
	/* 从异步通知列表中删除 */
	FakeIntGpioFasync(-1,file,0);
    return 0;
}

static ssize_t FakeIntGpioWrite(struct file *file, const char __user *buf,
                                size_t size, loff_t *off)
{
    int ret = 0;
    return ret;
}

static ssize_t FakeIntGpioRead(struct file *file, char __user *buf, size_t size,
                               loff_t *off)
{
    int ret = 0;
    unsigned char KeyValue = 0;
    ztIntGpio_I2C_read(FakeIntGpio.Int_Gpio_Adapter,&KeyValue);
    print("KeyValue ----- 0x%x\r\n",KeyValue);
    ret = copy_to_user(buf,&KeyValue,1);

    return ret;
}



static int FakeIntGpioFasync(int fd, struct file*file, int mode)
{
	struct FakeIntGpioDev *pdev = (struct FakeIntGpioDev *)file->private_data;

	return fasync_helper(fd,file,mode,&pdev->Nec_queue);

}


static int ztIntGpio_I2C_read(struct i2c_adapter *adapter,unsigned char *pBuf)
{
    struct i2c_msg msg[1];

    if (pBuf == NULL) return -1;

    /*  消息是读消息 */
    msg[0].addr = 0xAB;
    msg[0].flags = I2C_M_RD;
    msg[0].len = 1;
    msg[0].buf = pBuf;


    if (i2c_transfer(adapter, msg, 1) != 1) {
        print(" %s: i2c transfer fail\n", __func__);
        return -EIO;
    }
    else { 
   //   print(" %s: i2c transfer success\n", __func__);
    }

    return 0;
}
