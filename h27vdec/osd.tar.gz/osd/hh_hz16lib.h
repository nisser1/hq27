/**************************************************************************
 * 	FileName:		hh_hz16lib.h
 *	Description:	
 *	Copyright(C):	2006-2008 HHDigital Inc.
 *	Version:		V 1.0
 *	Author:			ChenYG
 *	Created:		2008-08-25
 *	Updated:		
 *					
 **************************************************************************/
#ifndef   _HH_HZ16LIB_H_
#define   _HH_HZ16LIB_H_

#define REAL_HZ16_COUNT			8178							//5165
extern	unsigned char   g_real_HZ16p[] ;						//���ֿ�					
extern	unsigned char   g_real_HZ12p[]; 						//LJM
extern  unsigned char   g_real_HZ8p[];                          
#endif

